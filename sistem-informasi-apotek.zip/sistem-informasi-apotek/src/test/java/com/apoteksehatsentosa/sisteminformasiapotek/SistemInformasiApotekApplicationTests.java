package com.apoteksehatsentosa.sisteminformasiapotek;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemInformasiApotekApplicationTests {

	@Test
	void contextLoads() {
	}

}
